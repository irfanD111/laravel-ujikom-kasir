<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset("css/login.css")); ?>">
</head>
<body>
    <div class="login-page">
        <form action=<?php echo e(url('/tambah-admin')); ?> method="post">
            <?php echo method_field('POST'); ?>
            <?php echo csrf_field(); ?>
        <div class="form">
            <form class="register-form">
                <h1>BUAT AKUN ADMIN</h1>
                <input type="text" placeholder="username" name="username"/>
                <input type="password" placeholder="password" name="password"/>
                <input type="text" placeholder="full name" name ="fn"/>
                <button>BUAT</button>
              </form>
            </form>
        </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\UJIKOM2023\resources\views/tambah_admin.blade.php ENDPATH**/ ?>