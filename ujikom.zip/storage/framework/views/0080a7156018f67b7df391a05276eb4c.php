<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br>
    <div class="container">
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col" colspan="4" style="text-align: center">
                        <h1>Data Produk</h1>
                    </th>
                </tr>
                <tr>
                  <th scope="col" style="text-align: center">#</th>
                  <th scope="col" style="text-align: center">First</th>
                  <th scope="col" style="text-align: center">Last</th>
                  <th scope="col" style="text-align: center">Handle</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">1</th>
                  <td>Mark</td>
                  <td>Otto</td>
                  <td>@mdo</td>
                </tr>
              </tbody>
        </table>
    </div>
      </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\UJIKOM2023\resources\views/data-produk.blade.php ENDPATH**/ ?>