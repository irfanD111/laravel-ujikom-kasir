<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset("css/login.css")); ?>">
</head>
<body>
    <div class="login-page">
        <div class="form">
            <form action=<?php echo e(url('/login/admin')); ?> method="post">
                <?php echo method_field("post"); ?>
                <?php echo csrf_field(); ?> 
            <form class="login-form">
                <h1>login admin</h1>
                <input type="text" placeholder="username" name="username"/>
                <input type="password" placeholder="password" name="password"/>
                <button type="submit">login</button>
            </form>
          </form>
        </div>
</body>
</html>



<?php /**PATH C:\xampp\htdocs\UJIKOM2023\resources\views/login-admin.blade.php ENDPATH**/ ?>