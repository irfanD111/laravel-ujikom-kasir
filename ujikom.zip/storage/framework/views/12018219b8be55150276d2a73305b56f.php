<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
</head>

<body>
    <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br>
    <?php if(session()->has('info')): ?>
        <div class="alert alert-danger" role="alert" style="text-align: center; width:50%; margin:auto">
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>
    <br>
    <h1 style="text-align: center">PENJUALAN</h1>
    <br>
    <div class="container">
        <form action=<?php echo e(url('/tambah-penjualan')); ?> method="POST">
            <?php echo method_field('POST'); ?>
            <?php echo csrf_field(); ?>

            <label class="row row-cols-lg-auto g-3 align-items-center"
                style="  display: grid; grid-template-columns: auto auto auto; gap: 10px 10px;">

                <div class="col-12">
                    <select class="form-select" name="produk" required>
                        <option selected>Pilih Produk...</option>
                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($produk->id); ?>"><?php echo e($produk->NamaProduk); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <input type="hidden" name="idpenjualan" value=<?php echo e($idpenjualan); ?>>
                <div class="col-12">
                    <label class="visually-hidden" for="inlineFormInputGroupUsername">Jumlah Produk</label>
                    <div class="input-group">
                        <div class="form-outline" data-mdb-input-init>
                            <input type="number" id="typeNumber" class="form-control" value="qty" name="qty" min="1" placeholder="qty" required />
                          </div>
                    </div>
                   
                </div>
                <select class="form-select" name ="pelanggan">
                    <option >Nama Pelanggan</option>
                    <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pelanggan->pelangganID); ?>"><?php echo e($pelanggan->NamaPelanggan); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <div class="col-12">
                    <button class="btn btn-outline-dark">Tambah</button>
                </div>
            </label>
        </form>
    </div>
    <BR><br>
    <div class="container">
        <div class="table-responsive">
            <table class="table table-bordered" style="width:80%">
                <thead>
                    <tr>
                        <th scope="col" style="text-align: center; width:5%">no</th>
                        <th scope="col" style="text-align: center; width:5%">Nama Produk</th>
                        <th scope="col" style="text-align: center; width:5%">Harga</th>
                        <th scope="col" style="text-align: center;width:5%">Qty</th>
                        <th scope="col" style="text-align: center; width:5%">Sub Total</th>
                    </tr>
                </thead>
                <?php $no = 1;
                $total_harga = 0;
                // $qty = $detailpenjualan->JumlahProduk
                // $pro = $detailpenjualan->ProdukID
                // $stok = $detailpenjualan->Stok
                ?>
                <tbody>
                    <?php $__currentLoopData = $detailpenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailpenjualan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align: center"><?php echo e($no++); ?></td>
                            <td style="text-align: center"><?php echo e($detailpenjualan->NamaProduk); ?></td>
                            <td style="text-align: center"><?php echo e($detailpenjualan->Harga); ?></td>
                            <td style="text-align: center"><?php echo e($detailpenjualan->JumlahProduk); ?></td>
                            <td style="text-align: center"><?php echo e($detailpenjualan->SubTotal); ?></td>
                            <?php $total_harga = $total_harga + $detailpenjualan->SubTotal; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
    <div class="container">
        <h1> Total Harga : <?php echo e(number_format($total_harga, 0, ',', '.')); ?></h1>
    </div>
    <div class="container">
        <form action=<?php echo e(url('Checkout')); ?> method="POST">
            <?php echo method_field('POST'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="idpenjualan" value=<?php echo e($idpenjualan); ?>>
            <input type="hidden" name="total" value=<?php echo e($total_harga); ?>>
            <button type="submit" class="btn btn-outline-dark">Checkout</button>

        </form>
    </div>
    <script>
        setTimeout(function() {
            $(".alert").fadeIn().delay(3000).fadeOut();
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\UJIKOM2023\resources\views//penjualan.blade.php ENDPATH**/ ?>